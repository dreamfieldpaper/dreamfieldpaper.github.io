#!/bin/bash

GPUS=$1
QUERY=$2

echo "GPUS $GPUS"
echo "QUERY $QUERY"

DOCKER_BUILDKIT=1 docker build -t dreamfields:v1 .

mkdir -p results

docker run --gpus $GPUS \
  -e XLA_PYTHON_CLIENT_PREALLOCATE=false \
  -v $HOME/.cache/scenic:/root/.cache/scenic \
  -v `pwd`/results:/dreamfields/results \
  --ipc=host dreamfields:v1 \
  python run.py --config=dreamfields/config/config_lq.py --query="$QUERY"
