"""Setup dreamfields package."""

import setuptools

setuptools.setup(
    name="dreamfields",
    version="0.1.0",
    packages=setuptools.find_packages(include=["dreamfields", "dreamfields.*"]),
    description="Text to 3D",
    author="Anon",
    install_requires=[
        "absl-py",
        "clu",
        "clip @ git+https://github.com/openai/CLIP.git",
        "dm_pix",
        "jax",
        "jaxlib",
        "flax",
        "matplotlib>=3.3.0",  # this version adds the turbo cmap
        "mediapy",
        "ml_collections",
        "numpy",
        "regex",
        "scenic @ git+git://github.com/google-research/scenic.git",
        "scipy",
        "tensorflow>=2.7.0",
        "tqdm",
        "torch"
    ],
)
