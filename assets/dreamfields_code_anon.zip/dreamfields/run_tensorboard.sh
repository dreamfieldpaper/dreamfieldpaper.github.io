#!/bin/bash

PORT=$1
docker run --rm -it -v `pwd`/results:/results \
        -e XLA_PYTHON_CLIENT_PREALLOCATE=false \
        -w /results -p $PORT:$PORT \
        --ipc=host nvcr.io/nvidia/tensorflow:21.12-tf2-py3 \
        tensorboard --logdir . --port $PORT
