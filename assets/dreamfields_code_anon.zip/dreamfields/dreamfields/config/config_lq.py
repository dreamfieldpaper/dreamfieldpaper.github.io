"""Low quality configuration."""

from dreamfields.config import config_base


def get_config(iters=10000):  # pylint: disable=invalid-name
  """Generate low quality config dict.

  Args:
    iters (int): Number of training iterations. Some hyperparameter schedules
      are based on this value, as well as the total training duration.

  Returns:
    config (ml_collections.ConfigDict): Configuration object.
  """

  config = config_base.get_config(iters=iters)
  config.render_width = 88
  config.crop_width = 80

  return config
